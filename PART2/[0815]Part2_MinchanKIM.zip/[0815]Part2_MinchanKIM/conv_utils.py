"""[0813] Part 2 과제 — 환경 설정 + convolution · U-Net 시각화 도우미.

노트북에서는 이 두 줄이면 준비가 끝납니다.

    from conv_utils import *
    globals().update(setup())

`setup()` 이 라이브러리 설정 · 이미지 로드 · 커널 준비 · convolution 계산까지
한 번에 처리하고, 노트북에서 쓸 이름들을 dict로 돌려줍니다.

그래프 안 글자는 한글 폰트가 없는 환경(Colab 등)에서 깨지므로 영어로 씁니다.
"""

import io
import os
import re
import math
import time
import random
import base64
import pickle
import shutil
import tarfile
import tempfile
import contextlib
import urllib.request
from pathlib import Path
from collections import Counter

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib import patches
from PIL import Image
from IPython.display import HTML, display

import torch
import torch.nn as nn
import torch.nn.functional as F


#  `from conv_utils import *` 로 노트북에 넘겨줄 이름들
__all__ = [
    # 라이브러리
    "os", "math", "random", "Path",
    "np", "plt", "Image",
    "HTML", "display",
    "torch", "nn", "F",
    # 환경 설정
    "setup",
    # 도우미 함수
    "load_gray",
    "conv2d_steps",
    "apply_kernel",
    "draw_matrix",
    "output_style",
    "render_step",
    "show_step",
    "show_steps_grid",
    "show_conv_overview",
    "sweep_gif",
    "show_kernel_result",
    # U-Net 시각화
    "show_feature_maps",
    # RNN / attention (섹션 3)
    "tokenize", "encode_docs", "imdb_setup",
    "train_classifier", "evaluate",
    "show_arch_compare", "make_longrange", "show_longrange",
    "show_noisy_pairs",
    "show_denoise_compare",
    "psnr",
    # 배포 데이터 번들
    "load_cifar", "BUNDLE_NAME",
]


#  기본 커널
SHARPEN = np.array([[ 0, -1,  0],
                    [-1,  5, -1],
                    [ 0, -1,  0]], dtype=float)

#  아직 계산하지 않은 출력 칸의 배경색 (회색조·빨강·파랑 어디와도 안 겹치게)
NOT_YET = "#f5edc8"


# ─────────────────────────────────────────────────────────────
#  환경 설정
# ─────────────────────────────────────────────────────────────
def setup(img_path="cat.jpeg", small_path="cat_64.png",
          kernel=None, kernel_name="sharpen",
          stride=1, padding=0, seed=42, verbose=True):
    """과제에 필요한 것들을 한 번에 준비하고 dict로 돌려준다.

    노트북에서는 이렇게 씁니다.

        globals().update(setup())

    돌려주는 이름
        SEED, DEVICE
        IMG_FULL, IMG              원본 / 축소 이미지 (0~1)
        KERNEL, KERNEL_NAME, STRIDE, PADDING
        XP, OUT, STEPS             convolution 계산 결과
        torchvision                모듈 자체 (설치돼 있지 않으면 None)
    """
    # 재현성
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    # torchvision 은 여기서 미리 불러 둔다. (2번에서 따로 import 하지 않도록)
    # 번들 데이터만 쓰면 없어도 과제가 돌아가므로, 없으면 None 으로 두고 넘어간다.
    try:
        import torchvision as _torchvision
    except Exception:
        _torchvision = None

    # 연산 장치
    if torch.cuda.is_available():
        device = torch.device("cuda")
    elif torch.backends.mps.is_available():
        device = torch.device("mps")
    else:
        device = torch.device("cpu")

    # 노트북 안이면 매직 명령을 걸어 둔다.
    #   inline     : 그림이 셀 아래에 바로 나오게
    #   autoreload : conv_utils.py 가 바뀌면 커널 재시작 없이 다시 읽게
    #                (파이썬은 한 번 import한 모듈을 캐시하므로, 이게 없으면
    #                 파일을 고쳐도 셀을 다시 돌릴 때 옛날 코드가 쓰인다)
    # 하나가 실패해도 나머지는 걸리도록 따로따로 감싼다.
    # 매직이 찍는 안내 문구는 삼킨다.
    #   (이 셀을 두 번 이상 돌리면 load_ext 가
    #    "The autoreload extension is already loaded..." 를 출력한다.
    #    예외가 아니라 print 라서 try 로는 안 잡히므로 stdout 을 돌려 둔다.)
    try:
        from IPython import get_ipython
        ip = get_ipython()
    except Exception:
        ip = None

    if ip is not None:
        with contextlib.redirect_stdout(io.StringIO()):
            for magic, arg in (("matplotlib", "inline"),
                               ("load_ext", "autoreload"),
                               ("autoreload", "2")):
                try:
                    ip.run_line_magic(magic, arg)
                except Exception:
                    pass

    plt.rcParams["figure.dpi"] = 110
    plt.rcParams["image.cmap"] = "gray"
    plt.rcParams["image.interpolation"] = "nearest"
    plt.rcParams["axes.grid"] = False

    # 이미지
    img_full = load_gray(img_path)
    img = load_gray(small_path)

    # 커널
    if kernel is None:
        kernel = SHARPEN
    kernel = np.asarray(kernel, dtype=float)

    # 커널이 놓이는 모든 자리를 미리 계산
    xp, out, steps = conv2d_steps(img, kernel, stride, padding)

    if verbose:
        print(f"torch {torch.__version__}   device {device}")
        print(f"이미지   원본 {img_full.shape}   축소 {img.shape}")
        print(f"커널     '{kernel_name}' {kernel.shape},  "
              f"stride {stride},  padding {padding}")
        print(f"출력     {out.shape}   (커널이 놓이는 자리 {len(steps)}개)")

    return dict(
        SEED=seed, DEVICE=device,
        IMG_FULL=img_full, IMG=img,
        KERNEL=kernel, KERNEL_NAME=kernel_name,
        STRIDE=stride, PADDING=padding,
        XP=xp, OUT=out, STEPS=steps,
        torchvision=_torchvision,
    )


# ─────────────────────────────────────────────────────────────
#  이미지
# ─────────────────────────────────────────────────────────────
def load_gray(path):
    """이미지를 흑백으로 읽어 0~1 범위의 2차원 배열로 돌려준다."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(
            f"'{path}' 을 찾을 수 없습니다. 노트북과 같은 폴더에 두고 다시 실행하세요."
        )
    return np.asarray(Image.open(path).convert("L"), dtype=float) / 255.0


# ─────────────────────────────────────────────────────────────
#  convolution
# ─────────────────────────────────────────────────────────────
def conv2d_steps(x, k, stride=1, padding=0):
    """2D convolution을 한 칸씩 계산하고 커널이 놓인 모든 위치를 기록한다.

    돌려주는 값
        xp    : padding이 적용된 입력
        out   : 출력 feature map
        steps : 각 위치의 기록 (커널 좌표, 출력 좌표, 계산값)
    """
    k = np.asarray(k, dtype=float)
    kh, kw = k.shape
    xp = np.pad(np.asarray(x, dtype=float), padding,
                mode="constant", constant_values=0)
    H, W = xp.shape

    if H < kh or W < kw:
        raise ValueError(f"커널({kh}x{kw})이 입력({H}x{W})보다 큽니다.")

    oh = (H - kh) // stride + 1
    ow = (W - kw) // stride + 1

    out = np.zeros((oh, ow), dtype=float)
    steps = []

    for oi in range(oh):
        for oj in range(ow):
            i0, j0 = oi * stride, oj * stride      # 커널 왼쪽 위 모서리
            patch = xp[i0:i0 + kh, j0:j0 + kw]     # 겹친 이미지 조각
            val = float((patch * k).sum())         # 원소별 곱 -> 전부 더하기

            out[oi, oj] = val
            steps.append(dict(oi=oi, oj=oj, i0=i0, j0=j0, value=val))

    return xp, out, steps


def apply_kernel(img, k, padding="same"):
    """이미지 전체에 커널을 한 번 적용한 결과를 돌려준다 (빠른 경로)."""
    k = np.asarray(k, dtype=float)
    if padding == "same":
        padding = (k.shape[0] // 2, k.shape[1] // 2)
    x = torch.tensor(np.asarray(img, dtype=float))[None, None]
    w = torch.tensor(k)[None, None]
    return F.conv2d(x, w, padding=padding).numpy()[0, 0]


# ─────────────────────────────────────────────────────────────
#  그리기
# ─────────────────────────────────────────────────────────────
def draw_matrix(ax, mat, title, box=None, shown=None, cmap="gray",
                vmin=None, vmax=None, annotate=None):
    """행렬 하나를 그린다. 작은 행렬이면 숫자와 격자도 함께 표시한다."""
    disp = np.array(mat, dtype=float)
    if shown is not None:
        disp = np.where(shown, disp, np.nan)       # 아직 안 채운 칸은 비움
        ax.set_facecolor(NOT_YET)                  # 비운 칸으로 배경색이 비쳐 보인다

    if vmin is None or vmax is None:
        finite = disp[np.isfinite(disp)]
        if finite.size and finite.max() != finite.min():
            vmin, vmax = finite.min(), finite.max()
        else:
            vmin, vmax = 0.0, 1.0

    ax.imshow(np.ma.masked_invalid(disp), cmap=cmap, vmin=vmin, vmax=vmax,
              interpolation="nearest")
    ax.set_title(title, fontsize=10)
    ax.set_xticks([])
    ax.set_yticks([])

    H, W = disp.shape
    if annotate is None:
        annotate = disp.size <= 64                 # 작을 때만 숫자

    if annotate:
        cm = plt.get_cmap(cmap)
        for i in range(H):
            for j in range(W):
                v = disp[i, j]
                if not np.isfinite(v):
                    continue
                t = 0.5 if vmax == vmin else (v - vmin) / (vmax - vmin)
                r, g, b, _ = cm(float(np.clip(t, 0, 1)))
                lum = 0.299 * r + 0.587 * g + 0.114 * b   # 어두우면 흰 글씨
                ax.text(j, i, f"{v:g}", ha="center", va="center", fontsize=9,
                        color="white" if lum < 0.5 else "black")

    if disp.size <= 256:                           # 작을 때만 격자
        ax.set_xticks(np.arange(-.5, W, 1), minor=True)
        ax.set_yticks(np.arange(-.5, H, 1), minor=True)
        ax.grid(which="minor", color="#b0b0b0", linewidth=0.8)
        ax.tick_params(which="minor", length=0)

    if box is not None:                            # 현재 커널 자리
        i0, j0, h, w = box
        ax.add_patch(patches.Rectangle((j0 - .5, i0 - .5), w, h, fill=False,
                                       edgecolor="crimson", linewidth=2.0))


def output_style(kernel, out):
    """출력 feature map을 어떤 색으로 그릴지 커널의 성격을 보고 정한다.

    커널 원소의 합이 1 근처면 밝기를 보존하는 커널(sharpen, blur ...)이라
    결과가 다시 '이미지'이므로 흑백으로 그린다.
    합이 0 근처면 밝기 변화(경계)만 뽑는 커널이라 결과가 0을 중심으로
    +/-로 갈리므로 빨강-파랑으로 그려 부호가 보이게 한다.
    """
    if abs(float(np.asarray(kernel, dtype=float).sum())) > 0.5:
        return dict(cmap="gray", vmin=0.0, vmax=1.0,
                    label="output  (black 0 ~ white 1)")

    lim = float(np.abs(out).max()) or 1.0
    return dict(cmap="RdBu_r", vmin=-lim, vmax=lim,
                label="output  (red +, blue -)")


def render_step(axes, xp, out, steps, t, kernel, kernel_name="kernel"):
    """t번째 step을 input / kernel / output 세 칸에 그린다."""
    s = steps[t]
    kernel = np.asarray(kernel, dtype=float)
    kh, kw = kernel.shape

    shown = np.zeros(out.size, dtype=bool)
    shown[:t + 1] = True                           # 왼->오, 위->아래 순서
    shown = shown.reshape(out.shape)

    k_lim = float(np.abs(kernel).max()) or 1.0
    style = output_style(kernel, out)

    draw_matrix(axes[0], xp, "input", box=(s["i0"], s["j0"], kh, kw),
                cmap="gray", vmin=0, vmax=1)
    draw_matrix(axes[1], kernel, f"kernel: {kernel_name}", cmap="RdBu_r",
                vmin=-k_lim, vmax=k_lim, annotate=True)
    draw_matrix(axes[2], out, style["label"], box=(s["oi"], s["oj"], 1, 1),
                shown=shown, cmap=style["cmap"],
                vmin=style["vmin"], vmax=style["vmax"])

    axes[1].set_xlabel(f"step {t + 1} / {len(steps)}", fontsize=9, labelpad=6)


def show_step(xp, out, steps, t, kernel, kernel_name="kernel"):
    """t번째 step 하나를 그림으로 출력한다."""
    fig, axes = plt.subplots(1, 3, figsize=(9.5, 3.2), dpi=90,
                             constrained_layout=True)
    render_step(axes, xp, out, steps, t, kernel, kernel_name)
    plt.show()


def sweep_gif(xp, out, steps, kernel, kernel_name="kernel",
              target_frames=140, fps=20, verbose=True, as_html=True):
    """커널이 훑고 지나가는 과정을 GIF로 만들어 자동 재생되도록 돌려준다.

    step이 많으면 일정 간격으로 골라서 프레임 수를 줄인다.
    """
    every = max(1, len(steps) // target_frames)
    idxs = list(range(0, len(steps), every))
    if idxs[-1] != len(steps) - 1:
        idxs.append(len(steps) - 1)

    if verbose:
        print(f"{len(steps)} step 중 {every}칸마다 한 장  ->  총 {len(idxs)} 프레임")

    fig, axes = plt.subplots(1, 3, figsize=(9.5, 3.2), dpi=80,
                             constrained_layout=True)

    def _update(f):
        for ax in axes:
            ax.clear()
        render_step(axes, xp, out, steps, idxs[f], kernel, kernel_name)
        return []

    anim = animation.FuncAnimation(fig, _update, frames=len(idxs),
                                   interval=1000 / fps)

    # GIF는 파일로만 저장할 수 있어서(PillowWriter가 파일 경로를 요구한다)
    # 쓸 수 있는 폴더를 차례로 시도한다. 임시 폴더가 막혀 있거나 꽉 찬 환경이 있다.
    b64, last_err = None, None
    for where in (None, str(Path.cwd()), str(Path.home())):
        try:
            with tempfile.TemporaryDirectory(dir=where) as td:
                gif = Path(td) / "sweep.gif"
                anim.save(gif, writer=animation.PillowWriter(fps=fps))
                b64 = base64.b64encode(gif.read_bytes()).decode()
            break
        except Exception as err:                 # 저장 공간 부족, 권한 없음 등
            last_err = err

    plt.close(fig)

    if b64 is None:
        raise RuntimeError(
            f"GIF를 저장할 수 없습니다 ({type(last_err).__name__}: {last_err})"
        ) from last_err

    if not as_html:
        return b64
    return HTML(f'<img src="data:image/gif;base64,{b64}" style="max-width:100%">')


def show_kernel_result(img, kernel, kernel_name="my kernel"):
    """원본 · 커널 · 적용 결과를 나란히 보여준다."""
    kernel = np.asarray(kernel, dtype=float)
    y = apply_kernel(img, kernel)

    fig, axes = plt.subplots(1, 3, figsize=(9.5, 3.2), dpi=90,
                             constrained_layout=True)
    k_lim = float(np.abs(kernel).max()) or 1.0
    style = output_style(kernel, y)

    draw_matrix(axes[0], img, "input", cmap="gray", vmin=0, vmax=1)
    draw_matrix(axes[1], kernel, f"kernel: {kernel_name}", cmap="RdBu_r",
                vmin=-k_lim, vmax=k_lim, annotate=True)
    draw_matrix(axes[2], y, style["label"], cmap=style["cmap"],
                vmin=style["vmin"], vmax=style["vmax"])
    plt.show()
    return y


# ─────────────────────────────────────────────────────────────
#  U-Net 시각화
# ─────────────────────────────────────────────────────────────
def _as_batch(img, device=None):
    """2차원 이미지를 (1, 1, H, W) 텐서로 바꾼다."""
    x = torch.tensor(np.asarray(img, dtype=np.float32))[None, None]
    return x.to(device) if device is not None else x


def show_feature_maps(feats, order=None, title="feature maps"):
    """각 단계의 feature map을 채널 평균 한 장으로 줄여서 나란히 보여준다.

    order를 주지 않으면 feats에 담긴 순서 그대로 그린다.
    """
    if order is None:
        order = list(feats.keys())

    n = len(order)
    fig, axes = plt.subplots(1, n, figsize=(1.7 * n, 2.6),
                             constrained_layout=True)
    axes = np.atleast_1d(axes)

    for a, k in zip(axes, order):
        t = feats[k].detach().float().cpu()[0]
        m = t.mean(0).numpy()                      # 채널 평균
        a.imshow(m, cmap="gray")
        a.set_title(f"{k}\n{t.shape[-1]}x{t.shape[-1]}, {t.shape[0]}ch",
                    fontsize=8)
        a.set_xticks([]); a.set_yticks([])

    fig.suptitle(title, fontsize=11)
    plt.show()


#  배포 번들 (다운로드 없이 쓰는 데이터 꾸러미)
BUNDLE_NAME = "dsl_part2_data.npz"


def _load_bundle(root):
    """data/dsl_part2_data.npz 를 읽는다. 없으면 None."""
    p = Path(root) / BUNDLE_NAME
    if not p.exists():
        return None
    try:
        return np.load(p, allow_pickle=False)
    except Exception as err:
        print(f"[안내] 데이터 번들을 읽지 못했습니다 ({err}). 원본을 내려받습니다.")
        return None


def load_cifar(root="./data", n_train=4000, n_test=16, verbose=True):
    """CIFAR-10 일부를 0~1 범위의 (N, 3, 32, 32) 실수 텐서로 돌려준다.

    배포 번들이 있으면 그것을 읽고, 없으면 torchvision으로 내려받는다.
    """
    b = _load_bundle(root)
    if b is not None and "CIFAR_TRAIN" in b.files:
        def to_t(a):
            return torch.tensor(a).permute(0, 3, 1, 2).float() / 255
        tr, te = to_t(b["CIFAR_TRAIN"]), to_t(b["CIFAR_TEST"])
        if n_train > len(tr) or n_test > len(te):
            raise ValueError(
                f"번들에는 학습 {len(tr)}장 / 평가 {len(te)}장만 들어 있습니다. "
                f"(요청: {n_train} / {n_test})")
        tr, te = tr[:n_train], te[:n_test]
        if verbose:
            print(f"CIFAR-10 : 번들에서 읽음 (다운로드 없음)")
        return dict(train=tr, test=te)

    if verbose:
        print("번들이 없어 torchvision으로 내려받습니다 (약 170MB, 처음 한 번만) ...")
    import torchvision
    import torchvision.transforms as _tfm
    tf = _tfm.ToTensor()
    a = torchvision.datasets.CIFAR10(root, train=True, download=True, transform=tf)
    c = torchvision.datasets.CIFAR10(root, train=False, download=True, transform=tf)
    tr = torch.stack([a[i][0] for i in range(n_train)])
    te = torch.stack([c[i][0] for i in range(n_test)])
    return dict(train=tr, test=te)


def psnr(pred, target):
    """복원 품질 지표 (dB). 높을수록 원본에 가깝고, 3dB 오르면 평균제곱오차(MSE)가 절반."""
    mse = float(((np.asarray(_to_np(pred)) - np.asarray(_to_np(target))) ** 2).mean())
    if mse <= 0:
        return float("inf")
    return 10.0 * math.log10(1.0 / mse)


def _to_np(t):
    """(N, C, H, W) 텐서를 numpy로."""
    if isinstance(t, torch.Tensor):
        return t.detach().float().cpu().numpy()
    return np.asarray(t)


def _to_hwc(t):
    """(N, C, H, W) -> (N, H, W, C), 0~1로 자른다."""
    return np.clip(np.transpose(_to_np(t), (0, 2, 3, 1)), 0, 1)


def show_noisy_pairs(clean, noisy, n=8):
    """깨끗한 이미지와 노이즈를 섞은 입력을 위아래로 나란히 보여준다."""
    c, z = _to_hwc(clean)[:n], _to_hwc(noisy)[:n]
    n = len(c)

    fig, axes = plt.subplots(2, n, figsize=(1.3 * n, 3.0),
                             constrained_layout=True)
    for j in range(n):
        axes[0, j].imshow(c[j]); axes[1, j].imshow(z[j])
        for r in (0, 1):
            axes[r, j].set_xticks([]); axes[r, j].set_yticks([])
    axes[0, 0].set_ylabel("clean\n(target)", fontsize=8)
    axes[1, 0].set_ylabel("noisy\n(input)", fontsize=8)
    plt.show()

    print(f"노이즈 낀 입력 그대로의 PSNR : {psnr(noisy, clean):.2f} dB")
    print("  (모델은 이 숫자보다 높아야 '노이즈를 줄였다'고 할 수 있습니다)")


def show_denoise_compare(clean, noisy, pred_skip, pred_noskip,
                         hist_skip=None, hist_noskip=None, n=8):
    """skip 유/무 결과를 test 이미지로 나란히 놓고 PSNR을 비교한다."""
    rows = [(_to_hwc(clean), "clean (target)", None),
            (_to_hwc(noisy), "noisy input", psnr(noisy, clean)),
            (_to_hwc(pred_skip), "with skip", psnr(pred_skip, clean)),
            (_to_hwc(pred_noskip), "no skip", psnr(pred_noskip, clean))]
    n = min(n, len(rows[0][0]))

    fig, axes = plt.subplots(4, n, figsize=(1.3 * n, 5.8),
                             constrained_layout=True)
    for r, (imgs, label, db) in enumerate(rows):
        for j in range(n):
            axes[r, j].imshow(imgs[j])
            axes[r, j].set_xticks([]); axes[r, j].set_yticks([])
        tag = label if db is None else f"{label}\n{db:.1f} dB"
        axes[r, 0].set_ylabel(tag, fontsize=8)
    fig.suptitle("test set (not used for training)", fontsize=10)
    plt.show()

    base, a, b = rows[1][2], rows[2][2], rows[3][2]
    print(f"PSNR   noisy 입력 {base:.2f} dB  |  with skip {a:.2f} dB"
          f"  |  no skip {b:.2f} dB")
    print(f"       skip이 {a - b:+.2f} dB 우세"
          f"   (오차 기준 {10 ** ((a - b) / 10):.1f}배 차이)")
    if b < base:
        print(f"       no skip은 노이즈 낀 입력보다도 {base - b:.2f} dB 나쁩니다.")

    if hist_skip is not None and hist_noskip is not None:
        fig, ax = plt.subplots(figsize=(6.4, 3.0), constrained_layout=True)
        ax.plot(hist_skip, label="with skip", linewidth=0.9)
        ax.plot(hist_noskip, label="no skip", linewidth=0.9)
        ax.set_yscale("log"); ax.set_xlabel("step", fontsize=9)
        ax.set_title("training loss (log scale)", fontsize=10)
        ax.legend(fontsize=9); ax.grid(alpha=0.3)
        plt.show()


# ─────────────────────────────────────────────────────────────
#  IMDB (섹션 3 — RNN / attention)
# ─────────────────────────────────────────────────────────────
IMDB_URL = "https://ai.stanford.edu/~amaas/data/sentiment/aclImdb_v1.tar.gz"
_TOKEN = re.compile(r"[a-z0-9']+")


def tokenize(text):
    """소문자로 바꾸고 단어만 뽑는다. HTML 줄바꿈 태그는 지운다."""
    return _TOKEN.findall(text.lower().replace("<br />", " "))


def _download_imdb(root):
    """aclImdb 를 내려받아 푼다. 이미 있으면 건너뛴다."""
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    d = root / "aclImdb"
    if d.exists():
        return d

    tgz = root / "aclImdb_v1.tar.gz"
    if not tgz.exists():
        print(f"IMDB 다운로드 중 (약 80MB) ... {IMDB_URL}")
        try:
            urllib.request.urlretrieve(IMDB_URL, tgz)
        except Exception as err:
            tgz.unlink(missing_ok=True)          # 받다 만 파일은 지운다
            raise RuntimeError(
                f"IMDB를 내려받지 못했습니다 ({type(err).__name__}: {err}).\n"
                f"네트워크를 확인하고 다시 실행하거나, 아래 주소에서 직접 받아\n"
                f"  {IMDB_URL}\n"
                f"'{root}/aclImdb_v1.tar.gz' 로 저장한 뒤 이 셀을 다시 실행하세요."
            ) from err

    print("압축 푸는 중 ...")
    with tarfile.open(tgz) as f:
        try:
            f.extractall(root, filter="data")    # Python 3.12+ 권장 방식
        except TypeError:                        # 구버전 파이썬에는 filter 인자가 없다
            f.extractall(root)
    return d


def _read_imdb(d):
    out = {}
    for split in ("train", "test"):
        xs, ys = [], []
        for label, y in (("pos", 1), ("neg", 0)):
            for f in sorted((d / split / label).iterdir()):
                if f.suffix == ".txt":
                    xs.append(tokenize(f.read_text(encoding="utf-8",
                                                   errors="ignore")))
                    ys.append(y)
        out[split] = (xs, ys)
    return out


def encode_docs(docs, stoi, max_len):
    """토큰 목록을 정수 배열로. 길이도 함께 돌려준다 (패딩 구분용)."""
    out = np.zeros((len(docs), max_len), dtype=np.int64)
    lens = np.zeros(len(docs), dtype=np.int64)
    for i, d in enumerate(docs):
        ids = [stoi.get(w, 1) for w in d[:max_len]]
        out[i, :len(ids)] = ids
        lens[i] = max(len(ids), 1)
    return torch.tensor(out), torch.tensor(lens)


def _len_bins(raw, max_len):
    """리뷰 길이를 3등분한다. raw는 원문 토큰 수.

    max_len을 넘는 리뷰는 데이터에서 이미 제외했으므로 여기 오는 것은
    모두 잘리지 않은 리뷰다. 따라서 세 구간은 정보 손실 없이
    '길이만' 달라진 조건이 된다.
    """
    q1, q2 = np.percentile(raw, [100 / 3, 200 / 3])
    bins = [("짧음", raw <= q1),
            ("중간", (raw > q1) & (raw <= q2)),
            ("긺",   raw > q2)]
    return bins, q1, q2


def _print_len_bins(raw, bins, q1, q2, max_len):
    """길이 구간을 어떻게 나눴는지 보여준다."""
    print(f"리뷰 길이 중앙값 {np.median(raw):.0f} 토큰  "
          f"(모두 {max_len}토큰 이하, 잘린 리뷰 없음)")
    print(f"길이 구간 (경계 {q1:.0f} / {q2:.0f})")
    for lab, m in bins:
        lo, hi = int(raw[m].min()), int(raw[m].max())
        pad = " " * (4 - 2 * len(lab))            # 한글 폭 보정
        print(f"    {lab}{pad} {lo:>4}~{hi:<4} 토큰   {int(m.sum()):>6}개")


def imdb_setup(root="./data", max_len=400, vocab_size=20000,
               n_train=20000, seed=0, keep_raw=False, verbose=True):
    """IMDB를 준비해 노트북에서 쓸 이름들을 dict로 돌려준다.

    1순위 : 배포 번들(data/dsl_part2_data.npz) — 다운로드 없이 바로 읽는다.
    2순위 : 토크나이징 캐시(imdb_tok.pkl)
    3순위 : 원본을 내려받아 토크나이징 (약 80MB, 몇 분 걸림)
    """
    root = Path(root)

    # ── 1순위 : 배포 번들 ──
    b = _load_bundle(root)
    if b is not None and "X_TRAIN" in b.files:
        same = (int(b["MAX_LEN"]) == max_len and
                int(b["VOCAB_SIZE"]) == vocab_size and
                int(b["N_TRAIN"]) == n_train and
                int(b["SEED"]) == seed)
        if same:
            itos = [str(w) for w in b["ITOS"]]
            raw = b["RAW_LEN"]
            bins, q1, q2 = _len_bins(raw, max_len)

            def _t(name):
                return torch.tensor(b[name].astype(np.int64))

            if verbose:
                print(f"IMDB : 번들에서 읽음 (다운로드 없음)")
                print(f"학습 {tuple(b['X_TRAIN'].shape)}   "
                      f"평가 {tuple(b['X_TEST'].shape)}")
                print(f"vocab {len(itos):,}개,  max_len {max_len}")
                _print_len_bins(raw, bins, q1, q2, max_len)

            return dict(
                X_TRAIN=_t("X_TRAIN"), L_TRAIN=_t("L_TRAIN"), Y_TRAIN=_t("Y_TRAIN"),
                X_TEST=_t("X_TEST"),   L_TEST=_t("L_TEST"),   Y_TEST=_t("Y_TEST"),
                ITOS=itos, STOI={w: i for i, w in enumerate(itos)},
                LEN_BINS=bins, MAX_LEN=max_len,
                # 예시 출력용으로 앞쪽 몇 개만 원문 토큰을 담아 두었다
                TEST_TOKENS=[str(s).split() for s in b["HEAD"]],
            )
        if verbose:
            print("번들의 설정이 요청과 달라 원본을 처리합니다 ...")

    cache = root / "imdb_tok.pkl"
    if cache.exists():
        data = pickle.loads(cache.read_bytes())
    else:
        raw_dir = _download_imdb(root)
        data = _read_imdb(raw_dir)
        cache.write_bytes(pickle.dumps(data))

        if not keep_raw:                       # 원본은 이제 필요 없다
            shutil.rmtree(raw_dir, ignore_errors=True)
            (root / "aclImdb_v1.tar.gz").unlink(missing_ok=True)
            if verbose:
                print("원본 파일 정리 완료 (imdb_tok.pkl 만 남김)")

    (tr_x, tr_y), (te_x, te_y) = data["train"], data["test"]

    # max_len을 넘는 리뷰는 뒷부분이 잘려 나가므로 아예 제외한다.
    # (번들을 만드는 make_bundle.py와 같은 규칙)
    def _drop_long(xs, ys):
        keep = [i for i, d in enumerate(xs) if len(d) <= max_len]
        return [xs[i] for i in keep], [ys[i] for i in keep]

    tr_x, tr_y = _drop_long(tr_x, tr_y)
    te_x, te_y = _drop_long(te_x, te_y)

    # 자주 나온 단어만 vocab에 넣는다. 0=<pad>, 1=<unk>
    cnt = Counter(w for d in tr_x for w in d)
    itos = ["<pad>", "<unk>"] + [w for w, _ in cnt.most_common(vocab_size - 2)]
    stoi = {w: i for i, w in enumerate(itos)}

    rng = np.random.default_rng(seed)
    sel = rng.permutation(len(tr_x))[:n_train]
    tr_x = [tr_x[i] for i in sel]
    tr_y = [tr_y[i] for i in sel]

    Xtr, Ltr = encode_docs(tr_x, stoi, max_len)
    Xte, Lte = encode_docs(te_x, stoi, max_len)

    # 길이 구간은 원문 토큰 수 기준으로 나눈다 (모두 max_len 이하)
    raw = np.array([len(d) for d in te_x])
    bins, q1, q2 = _len_bins(raw, max_len)

    if verbose:
        print(f"학습 {tuple(Xtr.shape)}   평가 {tuple(Xte.shape)}")
        print(f"vocab {len(itos):,}개,  max_len {max_len}")
        _print_len_bins(raw, bins, q1, q2, max_len)

    return dict(X_TRAIN=Xtr, L_TRAIN=Ltr, Y_TRAIN=torch.tensor(tr_y),
                X_TEST=Xte, L_TEST=Lte, Y_TEST=torch.tensor(te_y),
                ITOS=itos, STOI=stoi, LEN_BINS=bins,
                MAX_LEN=max_len, TEST_TOKENS=te_x)


def train_classifier(net, X, L, Y, device, epochs=3, batch_size=64,
                     lr=1e-3, clip=1.0, seed=42, verbose=True):
    """분류기를 학습시키고 (걸린 시간, loss 기록)을 돌려준다."""
    torch.manual_seed(seed)
    net = net.to(device)
    opt = torch.optim.Adam(net.parameters(), lr=lr)
    loss_fn = nn.CrossEntropyLoss()

    hist = []
    t0 = time.time()
    for ep in range(epochs):
        net.train()
        perm = torch.randperm(len(X))
        for i in range(0, len(X), batch_size):
            idx = perm[i:i + batch_size]
            xb, lb, yb = X[idx].to(device), L[idx].to(device), Y[idx].to(device)
            opt.zero_grad()
            loss = loss_fn(net(xb, lb), yb)
            loss.backward()
            nn.utils.clip_grad_norm_(net.parameters(), clip)
            opt.step()
            hist.append(loss.item())

    # GPU 연산은 비동기라, 실제로 끝날 때까지 기다린 뒤 시간을 재야 한다.
    # (기다리지 않으면 RNN과 attention의 학습 시간 비교가 왜곡된다)
    if device.type == "cuda":
        torch.cuda.synchronize()
    elif device.type == "mps":
        torch.mps.synchronize()
    dt = time.time() - t0

    if verbose:
        print(f"  학습 {dt:.1f}초   마지막 loss {hist[-1]:.4f}")
    return dt, hist


@torch.no_grad()
def evaluate(net, X, L, Y, device, bins=None, batch_size=256):
    """정확도를 잰다. bins를 주면 길이 구간별로도 잰다."""
    net.eval()
    preds = []
    for i in range(0, len(X), batch_size):
        preds.append(net(X[i:i + batch_size].to(device),
                         L[i:i + batch_size].to(device)).argmax(1).cpu())
    ok = (torch.cat(preds) == Y).numpy()
    if bins is None:
        return ok.mean(), None
    return ok.mean(), [(lab, ok[m].mean()) for lab, m in bins]


def show_arch_compare(rows):
    """{이름: (학습시간, 전체정확도, [(구간,정확도)...])} 를 표와 그래프로."""
    names = list(rows)
    print(f"\n{'모델':<16}{'학습 시간':>10}{'전체 정확도':>13}   "
          + "".join(f"{lab:>9}" for lab, _ in rows[names[0]][2]))
    for n in names:
        t, acc, per = rows[n]
        print(f"{n:<16}{t:>9.1f}s{acc:>13.4f}   "
              + "".join(f"{a:>9.4f}" for _, a in per))

    if len(names) >= 2:
        a, b = rows[names[0]], rows[names[1]]
        print(f"\n  학습 시간  {a[0]:.1f}s -> {b[0]:.1f}s "
              f"({a[0]/max(b[0],1e-9):.1f}배 빠름)")
        print(f"  정확도     {a[1]:.4f} -> {b[1]:.4f} ({b[1]-a[1]:+.4f})")

    fig, ax = plt.subplots(1, 2, figsize=(9.5, 3.2), constrained_layout=True)
    ax[0].bar(names, [rows[n][0] for n in names], color=["#c05a5a", "#4a7fb5"])
    ax[0].set_title("training time (s)", fontsize=10)
    ax[1].bar(names, [rows[n][1] for n in names], color=["#c05a5a", "#4a7fb5"])
    # 정확도가 0.5 아래로 내려가도 막대가 보이도록 아래끝을 맞춘다
    lo = min(rows[n][1] for n in names)
    ax[1].set_ylim(min(0.5, lo - 0.05), 1.0)
    ax[1].set_title("test accuracy", fontsize=10)
    for a_ in ax:
        a_.grid(axis="y", alpha=0.3)
    plt.show()


def make_longrange(n, T, seed=0, n_filler=48):
    """합성 장거리 과제. 단서는 위치 0에만 있고 나머지는 전부 무의미 토큰.

    T를 키우면 '정보를 얼마나 멀리 옮겨야 하는가'만 커진다.
    """
    rng = np.random.default_rng(seed)
    x = rng.integers(2, n_filler, size=(n, T))
    y = rng.integers(0, 2, size=n)
    x[:, 0] = np.where(y == 1, n_filler, n_filler + 1)     # 단서 두 종류
    return (torch.tensor(x), torch.tensor(y),
            torch.full((n,), T, dtype=torch.long))


def show_longrange(rows):
    """[(T, rnn_acc, rnn_t, attn_acc, attn_t), ...] 를 표와 그래프로."""
    print(f"\n{'거리 T':>7} | {'RNN 정확도':>11}{'시간':>8} | "
          f"{'attention 정확도':>17}{'시간':>8}")
    for T, ra, rt, aa, at in rows:
        mark = "   <- 붕괴" if ra < 0.6 else ""
        print(f"{T:>7} | {ra:>11.4f}{rt:>7.1f}s | {aa:>17.4f}{at:>7.1f}s{mark}")

    Ts = [r[0] for r in rows]
    fig, ax = plt.subplots(1, 2, figsize=(9.5, 3.2), constrained_layout=True)
    ax[0].plot(Ts, [r[1] for r in rows], "o-", label="RNN", color="#c05a5a")
    ax[0].plot(Ts, [r[3] for r in rows], "s-", label="attention", color="#4a7fb5")
    ax[0].axhline(0.5, ls="--", c="gray", lw=1)
    ax[0].text(Ts[0], 0.515, "chance", fontsize=8, color="gray")
    ax[0].set_ylim(0.4, 1.05)
    ax[0].set_xlabel("distance T", fontsize=9)
    ax[0].set_title("accuracy vs distance", fontsize=10)

    ax[1].plot(Ts, [r[2] for r in rows], "o-", label="RNN", color="#c05a5a")
    ax[1].plot(Ts, [r[4] for r in rows], "s-", label="attention", color="#4a7fb5")
    ax[1].set_xlabel("distance T", fontsize=9)
    ax[1].set_title("training time (s)", fontsize=10)

    for a_ in ax:
        a_.legend(fontsize=9); a_.grid(alpha=0.3)
    plt.show()


def _steps_grid_figure(xp, out, steps, ts, kernel, kernel_name="kernel",
                       ncols=2, panel=2.0):
    """여러 step을 격자로 그린 figure를 만들어 돌려준다 (화면에 띄우지는 않음).

    step 하나가 input / kernel / output 세 칸을 쓰므로,
    격자 한 칸은 subplot 세 개짜리 묶음이 된다.
    """
    ts = list(ts)
    nrows = math.ceil(len(ts) / ncols)

    fig, axes = plt.subplots(nrows, ncols * 3,
                             figsize=(panel * ncols * 3, panel * 1.35 * nrows),
                             dpi=90, constrained_layout=True)
    axes = np.atleast_2d(axes)

    for i, t in enumerate(ts):
        r, c = divmod(i, ncols)
        render_step(axes[r, c * 3:(c + 1) * 3], xp, out, steps, t,
                    kernel, kernel_name)

    for i in range(len(ts), nrows * ncols):        # 빈 칸은 지운다
        r, c = divmod(i, ncols)
        for a in axes[r, c * 3:(c + 1) * 3]:
            a.axis("off")
    return fig


def show_steps_grid(xp, out, steps, ts, kernel, kernel_name="kernel",
                    ncols=2, panel=2.0):
    """여러 step을 격자로 한 화면에 보여준다."""
    _steps_grid_figure(xp, out, steps, ts, kernel, kernel_name, ncols, panel)
    plt.show()


def _fig_to_b64(fig, dpi=100):
    """figure를 PNG base64 문자열로 바꾸고 닫는다."""
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=dpi, bbox_inches="tight",
                facecolor="white")
    plt.close(fig)
    return base64.b64encode(buf.getvalue()).decode()


def show_conv_overview(xp, out, steps, kernel, kernel_name="kernel",
                       ts=None, ncols=2, panel=2.0,
                       target_frames=140, fps=20, gif=True):
    """정지 화면 격자와 움직이는 GIF를 하나의 출력으로 묶어 보여준다.

    위 : 네 지점을 끊어 본 격자
    아래 : 처음부터 끝까지 훑는 애니메이션 (자동 재생, 반복)

    GIF는 만드는 데 시간이 걸리고 저장 공간도 조금 씁니다.
    필요 없거나 환경이 받쳐 주지 않으면 gif=False 로 끄면 됩니다.
    만들다 실패해도 위쪽 격자는 그대로 나옵니다.
    """
    n = len(steps)
    if ts is None:
        ts = [n // 4, n // 2, 3 * n // 4, n - 1]

    grid = _fig_to_b64(_steps_grid_figure(xp, out, steps, ts, kernel,
                                          kernel_name, ncols, panel))

    gif_b64 = None
    if gif:
        try:
            gif_b64 = sweep_gif(xp, out, steps, kernel, kernel_name,
                                target_frames=target_frames, fps=fps,
                                verbose=False, as_html=False)
        except Exception as err:
            print(f"[안내] 애니메이션을 만들지 못해 위쪽 격자만 표시합니다. ({err})")
            print("       저장 공간이 부족하거나 쓰기 권한이 없을 때 생깁니다.")
            print("       과제 진행에는 아무 영향이 없습니다. gif=False 로 아예 끌 수도 있습니다.")

    style = "max-width:100%; display:block; margin:0 auto 6px auto"
    html = (f'<div style="text-align:center">'
            f'<img src="data:image/png;base64,{grid}" style="{style}">')
    if gif_b64 is not None:
        html += f'<img src="data:image/gif;base64,{gif_b64}" style="{style}">'
    html += '</div>'
    return HTML(html)

